---
description: Produce a read-only map of the current project memory environment and source files.
---

# Project Memory Scan

Map the current environment without changing files.

## Preflight

1. Identify the current working directory.
2. Run `core/scripts/inspect_project.py` if available.
3. Check for existing memory system files and agent compatibility files.
4. Do not open or print secret values.

## Plan

State that this command is read-only and will produce:

- Folder tree summary.
- Source file categories.
- Agent/memory file status.
- Raw/extracted/memory health.
- Risks and recommended next actions.

## Commands

Run read-only inspection only:

- File inventory.
- Extension/type grouping.
- Existing agent file detection.
- Existing memory/source-index detection.
- Optional Mermaid or text tree for structure.

Do not move, write, delete, format, or initialize anything.

## Verification

Confirm no files were changed. If git exists, compare pre/post `git status --short`.

## Summary

Return:

```md
## Result
- **Action**: scan
- **Status**: success | partial | failed
- **Project Type Guess**: <type>
- **Memory Health**: <ready | partial | missing>
- **Key Risks**: <short list>
```

## Next Steps

Recommend one next command:

- `/setup` if no memory system exists.
- `/rework` if new raw files are present but not indexed.
- `/add-agent` if tool profiles are missing.

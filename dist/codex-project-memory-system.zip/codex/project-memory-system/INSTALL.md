# Install

This build is packaged for Codex.

Expected entry points:

- `.codex-plugin/plugin.json`
- `commands/`
- `skills/project-memory-system/`
- `scripts/`

Recommended first prompt:

- Set up this folder as a cross-agent project memory system

---
description: Inspect the current folder and propose a cross-agent project memory system before creating files.
---

# Project Memory Setup

Set up a cross-agent project memory system for the current folder.

## Preflight

1. Identify the current working directory and confirm it is the intended project root.
2. Run a read-only project inspection using `core/scripts/inspect_project.py` if available.
3. Check for existing `AGENTS.md`, `CLAUDE.md`, `CODEX.md`, `ANTIGRAVITY.md`, `GEMINI.md`, `memory/`, `raw/`, `project-system/`, and `logs/`.
4. Check for `.gitignore` and local git status without changing the repo.
5. Do not read or print secret values from `.env`, credentials, tokens, or ignored secret folders.

## Plan

Present a setup plan before writing anything. Include:

- Project type guess.
- Existing memory/agent files found.
- Proposed folder structure.
- Files that would be moved or copied.
- Files that would be created.
- Whether local git initialization is recommended.

Ask for explicit approval before mutation.

## Commands

After approval only:

1. Create the approved scaffold with `core/scripts/scaffold_memory_system.py` or equivalent manual file operations.
2. Preserve original source files under `raw/`.
3. Create `AGENTS.md` as the canonical entry point.
4. Create pointer-only compatibility files for requested tools.
5. Create `project-system/`, `memory/`, `workstreams/`, `deliverables/`, and `logs/`.
6. Generate an initial `memory/11-source-index.md` with `core/scripts/generate_source_index.py` when source material already exists.
7. Add a secrets-aware `.gitignore`.
8. Initialize local git only if explicitly approved.

## Verification

Verify:

- Canonical `AGENTS.md` exists.
- Compatibility files are pointer-only.
- Raw files were preserved.
- Memory files exist and contain placeholders or synthesized content.
- No secret files were copied into memory or logs.
- Existing files were not overwritten unless approved.

## Summary

Return:

```md
## Result
- **Action**: setup
- **Status**: success | partial | failed
- **Created**: <key folders/files>
- **Moved**: <raw source summary>
- **Skipped**: <reason>
```

## Next Steps

Suggest the next command:

- `/project-memory-system:scan` to review the environment.
- `/project-memory-system:rework` after adding new raw source files.
- `/project-memory-system:add-agent` to add a tool-specific profile.
- `/project-memory-system:subtasks` to discover parallelizable agent work.

---
description: Reconcile newly added raw files with the project memory system and propose updates before writing.
---

# Project Memory Rework

Use this after adding new source files, notes, exports, diagrams, or datasets.

## Preflight

1. Confirm the project has a memory system or identify what is missing.
2. Scan for new or changed files under raw/source/data folders.
3. Compare source files against `memory/11-source-index.md` or other source indexes.
4. Run `core/scripts/validate_rework.py` if available to flag risky inputs before extraction or copying.
4. Do not read or print secret values.

## Plan

Before writing anything, propose:

- New files detected.
- Where each file belongs.
- Whether each file should be preserved only, extracted to markdown, schema-profiled, or summarized.
- Memory files likely affected.
- Any files that should be ignored.

Ask for explicit approval before mutation.

## Commands

After approval only:

1. Move/copy files into the approved raw location if needed.
2. Extract DOCX/PDF/diagram content into markdown when useful.
3. Profile spreadsheets/CSVs into schema-level markdown by default.
4. Update source indexes with `core/scripts/generate_source_index.py` when available.
5. Draft synthesized memory updates with `core/scripts/draft_memory_update.py`, then keep only durable facts, decisions, assumptions, questions, or opportunities.
6. Add a log/handoff entry for meaningful work.

## Verification

Verify:

- Originals are preserved.
- Extracted markdown exists where expected.
- Memory/source indexes reference new files.
- No full sensitive datasets were duplicated unless explicitly requested.
- No secrets were logged.

## Summary

Return:

```md
## Result
- **Action**: rework
- **Status**: success | partial | failed
- **New Sources**: <count and categories>
- **Memory Updated**: <files>
- **Skipped**: <reason>
```

## Next Steps

Recommend what to do next, such as building from the updated workstream, running `/project-memory-system:scan`, or requesting missing source data.
